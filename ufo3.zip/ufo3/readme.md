This typeface is the result of collective work during the game «Chancho va» run into Typewknd 2021.  
It is open source, and its editable files are available from this repository.   
You can work on it with any type editor software but you should commit the UFO file.  
The UFO file are the	exchange files because they can be opened and edited with many font editors.  
Any feedback, bug reports, test results, and suggestions for additions are very welcome.   
You can contact us using the «Chancho Va» issue tracker hear in Git.  
   
If you like the project, let us know!

### How to edit 
- `Clone` the repo
- `Open` and `edit` UFO file with your favorite font editor
- `Export` UFO
- `Commit` what you've added/changed/modified 
- `Push` UFO files
- `Add` your name at the contributors list.

### License
The «Chancho va» font and all its associated font files are free software under the SIL Open Font License. Essentially, this gives you the right to download, use, and redistribute the fonts, provided that:

- you retain my copyright notices;
- you do not redistribute this software without this license information; and
- you do not redistribute the fonts by themselves for a fee (though you are allowed to sell them as part of a bundle containing other items.)
